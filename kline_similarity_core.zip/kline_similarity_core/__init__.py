"""
kline_similarity_core
=====================
Core K-Line Geometric Similarity Metric Learning Package.
Extracts 1D, 2D, and 3D dimensionless candlestick geometries and performs
prototype similarity matching against bullish breakout patterns.
"""

from .features import (
    build_kline_features,
    FEATURES_1DAY,
    FEATURES_2DAY,
    FEATURES_3DAY,
)
from .similarity_model import KlineSimilarityMatcher
from .deep_similarity_models import (
    DeepProtoMatcher,
    SiameseTripletMatcher,
)
from .pipeline import KlineSimilarityEngine

__all__ = [
    "build_kline_features",
    "FEATURES_1DAY",
    "FEATURES_2DAY",
    "FEATURES_3DAY",
    "KlineSimilarityMatcher",
    "DeepProtoMatcher",
    "SiameseTripletMatcher",
    "KlineSimilarityEngine",
]
