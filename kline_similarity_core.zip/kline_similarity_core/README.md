# 📐 K-Line Geometric Similarity Core
# （K 線幾何形態度量學習核心純淨庫）

本專案為量化台股投資組合中**「K 線微觀幾何度量學習與原型比對」**的獨立核心演算法庫。

> [!NOTE]
> **純淨化說明**：
> 本壓縮包已**完全排除**所有外部投資組合回測、模型比較實驗、摩擦測試腳本與視覺化圖表，**僅保留最純粹的「幾何特徵工程、原型聚類比對模型、度量學習算法與 Trinity Alpha 生成管線」**。

---

## 📂 檔案清單 (File Manifest)

```text
kline_similarity_core/
├── README.md                 # 核心算法原理與 API 使用說明文檔
├── __init__.py               # 套件統一導出介面
├── features.py               # 1D/2D/3D 無量綱 K 線幾何特徵向量化提取器
├── similarity_model.py       # 輕量級幾何原型聚類與餘弦度量比對模型 (KlineSimilarityMatcher)
├── deep_similarity_models.py # 深度神經度量學習比對模型 (DeepProtoMatcher, Siamese)
├── pipeline.py               # 端到端高階推論管線 (KlineSimilarityEngine)
└── example_usage.py          # 快速上手完整示範腳本 (含合成數據測試與模型保存加載)
```

---

## 🧠 核心技術與度量原理 (Core Methodology)

### 1. 無量綱 K 線幾何特徵工程 (`features.py`)
傳統技術指標（MA、MACD、RSI）多基於純價格時間序列，無法捕捉蠟燭線內部的多空博弈力道。本庫提取無量綱（Dimensionless）幾何特徵，天然具備跨股價、跨時間的尺度不變性：
- **1-Day 單根 K 線幾何**（10 維）：
  - 上下影線佔比 (`upper/lower_shadow_ratio`)、實體佔比 (`body_ratio`)、實體方向 (`body_signed`)
  - 收盤/開盤相對振幅位置 (`close/open_pos`)、影線不平衡度 (`shadow_imbalance`)、量能偏離 MA5 變化率
- **2-Day 雙日跳空與推進幾何**（34 維）：
  - 開盤跳空幅度 (`gap_open`)、K 線重疊率 (`overlap_ratio`)
  - 突破前日最高價邊界 (`breakout_high_margin`)、跌破前日最低價邊界 (`breakdown_low_margin`)
  - 4 點間歐氏幾何位移 (`dist_euclidean`) 與曼哈頓位移 (`dist_manhattan`)
- **3-Day 三日波段微觀幾何**（68 維）：
  - 走勢效率比 (`efficiency_ratio_3d` = 淨位移 / 累積路徑)
  - 價格曲率 (`price_curvature_3d` = 中間根相對端點連線的凹凸度)

---

### 2. 幾何原型聚類與餘弦度量比對 (`similarity_model.py`)
模型不直接使用黑盒分類器，而是透過**度量學習（Metric Learning）**：
1. **原型提取（Prototype Learning）**：
   - 使用 Mini-Batch K-Means 在歷史突破樣本（$Y=1$）中聚類出 $K$ 個**「多頭爆發幾何原型」**（Bullish Prototypes $\mathbf{P}^+$）。
   - 在歷史非突破/噪音樣本（$Y=0$）中聚類出 $K$ 個**「假突破/盤整幾何原型」**（Negative Prototypes $\mathbf{P}^-$）。
2. **超球面餘弦度量比對（Cosine Metric Matching）**：
   - 將任何待比對的 K 線特徵向量 $\mathbf{x}$ 投影至單位超球面（$L_2$ 歸一化）：
     $$S^+ = \mathbf{x} \cdot (\mathbf{P}^+)^T, \quad S^- = \mathbf{x} \cdot (\mathbf{P}^-)^T$$
3. **對比度量與邏輯校準（Calibration）**：
   - 計算與多頭原型的最高相似度、前 3 大平均相似度，以及多空對比度（Contrast = $S^+ - S^-$）。
   - 透過邏輯斯蒂校準器將餘弦距離平滑映射為實體突破機率。

---

### 3. Trinity Alpha 複合因子構造 (`pipeline.py`)
經量化實證，將短天期觸發點與中天期波段結構結合能達到最佳排雷效果：
$$\text{Trinity Alpha} = 0.3 \times \text{Rank}(\text{prob\_2d\_1d}) + 0.7 \times \text{Rank}(\text{prob\_3d\_5d})$$
- `prob_2d_1d`：2 日型態預測次日突破爆發機率（權重 30%，捕捉短線起漲點火點）
- `prob_3d_5d`：3 日波段型態預測 5 日延續機率（權重 70%，過濾短線假突破誘多）

---

## 💻 快速上手範例 (Quickstart)

可以直接執行包含完整數據流驗證的範例腳本：
```bash
python example_usage.py
```

### Python 代碼調用示例：
```python
import pandas as pd
from features import build_kline_features
from pipeline import KlineSimilarityEngine

# 1. 準備任意標的的 OHLCV DataFrame (需包含 date, stock_id, open, high, low, adj_close, volume)
df_ohlcv = pd.read_parquet("path/to/your/OHLCV.parquet")

# 2. 提取 1D/2D/3D 無量綱 K 線幾何特徵
df_features = build_kline_features(df=df_ohlcv, start_date="2024-01-01")

# 3. 初始化並訓練相似度比對引擎 (或直接載入預訓練模型)
engine = KlineSimilarityEngine(n_pos_prototypes=48, n_neg_prototypes=48, random_state=42)
engine.fit(df_features[df_features["date"] < "2025-01-01"])

# 4. 對未見行情執行相似度比對與 Trinity Alpha 預測
predictions = engine.predict(df_features[df_features["date"] >= "2025-01-01"])

# 5. 查看比對結果
print(predictions[["date", "stock_id", "prob_1d_5d", "prob_2d_1d", "prob_3d_5d", "kline_trinity_alpha"]])

# 6. 保存與載入模型
engine.save("kline_engine.pkl")
loaded_engine = KlineSimilarityEngine.load("kline_engine.pkl")
```

---

## 📦 依賴環境
- Python 3.9+
- `numpy`
- `pandas`
- `scikit-learn`
- `torch` (僅在使用 `deep_similarity_models.py` 深度神經度量時需要，核心引擎基於 scikit-learn 無深度學習硬體要求)
