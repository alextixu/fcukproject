"""
kline_similarity_core.features
==============================
Vectorized feature engineering for pure K-line dimensionless geometry:
- 1-Day Candlestick Geometry (Shadow ratios, body ratios, position, volume change)
- 2-Day Candlestick Geometry (Gap, overlap ratio, Manhattan/Euclidean displacement, breakout margins)
- 3-Day Candlestick Geometry (Price curvature, trend efficiency ratio, 3-day relative displacements)
- Binary Targets: Future 1D, 3D, 5D Return >= +3%
"""

from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd


FEATURES_1DAY = [
    "upper_shadow_ratio_t0",
    "lower_shadow_ratio_t0",
    "body_ratio_t0",
    "body_signed_t0",
    "close_pos_t0",
    "open_pos_t0",
    "shadow_imbalance_t0",
    "vol_change_vs_ma5_t0",
    "dist_high_low_t0",
    "dist_low_high_t0",
]

FEATURES_2DAY_DISTANCE = [
    "dist_open_t1",
    "dist_high_t1",
    "dist_low_t1",
    "dist_close_t1",
    "gap_open_t1",
    "dist_euclidean_t1",
    "dist_manhattan_t1",
    "dist_high_t0_low_t1",
    "dist_low_t0_high_t1",
    "dist_high_t1_low_t0",
    "dist_low_t1_high_t0",
    "overlap_ratio_t1",
    "breakout_high_margin_t1",
    "breakdown_low_margin_t1",
]

FEATURES_2DAY = (
    FEATURES_1DAY
    + [f"{c.replace('_t0', '_t1')}" for c in FEATURES_1DAY]
    + FEATURES_2DAY_DISTANCE
)

FEATURES_3DAY_DISTANCE = [
    "dist_open_t1_t2",
    "dist_high_t1_t2",
    "dist_low_t1_t2",
    "dist_close_t1_t2",
    "gap_open_t1_t2",
    "dist_euclidean_t1_t2",
    "dist_manhattan_t1_t2",
    "dist_high_t1_low_t2",
    "dist_low_t1_high_t2",
    "dist_high_t2_low_t1",
    "dist_low_t2_high_t1",
    "dist_open_t0_t2",
    "dist_high_t0_t2",
    "dist_low_t0_t2",
    "dist_close_t0_t2",
    "gap_open_t0_t2",
    "dist_euclidean_t0_t2",
    "dist_manhattan_t0_t2",
    "dist_high_t0_low_t2",
    "dist_low_t0_high_t2",
    "dist_high_t2_low_t0",
    "dist_low_t2_high_t0",
    "efficiency_ratio_3d",
    "price_curvature_3d",
]

FEATURES_3DAY = (
    FEATURES_2DAY
    + [f"{c.replace('_t0', '_t2')}" for c in FEATURES_1DAY]
    + FEATURES_3DAY_DISTANCE
)


def build_kline_features(
    df: pd.DataFrame | None = None,
    raw_data_path: str | Path | None = None,
    start_date: str = "2016-01-01",
    min_volume_lots: float = 1000.0,
    train_end: str = "2024-06-30",
    val_end: str = "2024-12-31",
    test_start: str = "2025-01-01",
) -> pd.DataFrame:
    """
    Computes complete 1D, 2D, and 3D dimensionless candlestick geometries
    from any input OHLCV DataFrame or Parquet file.
    """
    if df is None:
        if raw_data_path is None:
            # Fallback to local default path if present
            default_p = Path(__file__).resolve().parents[2] / "data" / "raw" / "OHLCV.parquet"
            if default_p.exists():
                raw_data_path = default_p
            else:
                raise ValueError("Must provide either 'df' or a valid 'raw_data_path'.")
        df = pd.read_parquet(raw_data_path)

    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df["stock_id"] = df["stock_id"].astype(str)
    df = df.sort_values(["stock_id", "date"]).reset_index(drop=True)

    n = len(df)
    s_id = df["stock_id"].values
    o = df["open"].values.astype(np.float64)
    h = df["high"].values.astype(np.float64)
    l = df["low"].values.astype(np.float64)
    c = df["adj_close"].values.astype(np.float64) if "adj_close" in df.columns else df["close"].values.astype(np.float64)
    v = df["volume"].values.astype(np.float64)

    same_1 = np.zeros(n, dtype=bool)
    same_1[1:] = (s_id[1:] == s_id[:-1])
    same_2 = np.zeros(n, dtype=bool)
    same_2[2:] = (s_id[2:] == s_id[:-2])
    same_3 = np.zeros(n, dtype=bool)
    same_3[3:] = (s_id[3:] == s_id[:-3])
    same_4 = np.zeros(n, dtype=bool)
    same_4[4:] = (s_id[4:] == s_id[:-4])
    same_5 = np.zeros(n, dtype=bool)
    same_5[5:] = (s_id[5:] == s_id[:-5])

    same_f1 = np.zeros(n, dtype=bool)
    same_f1[:-1] = (s_id[:-1] == s_id[1:])
    same_f3 = np.zeros(n, dtype=bool)
    same_f3[:-3] = (s_id[:-3] == s_id[3:])
    same_f5 = np.zeros(n, dtype=bool)
    same_f5[:-5] = (s_id[:-5] == s_id[5:])

    candle_range = h - l
    zero_range = candle_range <= 1e-8
    safe_range = np.where(zero_range, 1.0, candle_range)
    safe_c = np.where(c <= 1e-8, 1.0, c)

    # 1-Day Geometry (t0)
    max_oc = np.maximum(o, c)
    min_oc = np.minimum(o, c)
    upper_sh = np.clip((h - max_oc) / safe_range, 0.0, 1.0)
    lower_sh = np.clip((min_oc - l) / safe_range, 0.0, 1.0)
    body_r = np.clip(np.abs(c - o) / safe_range, 0.0, 1.0)
    body_s = np.clip((c - o) / safe_range, -1.0, 1.0)
    close_pos = np.clip((c - l) / safe_range, 0.0, 1.0)
    open_pos = np.clip((o - l) / safe_range, 0.0, 1.0)
    shadow_imb = np.clip((lower_sh - upper_sh), -1.0, 1.0)
    d_hl_t0 = np.clip((h - l) / safe_c, 0.0, 0.30)
    d_lh_t0 = -d_hl_t0

    # Volume MA5
    v_lag1 = np.where(same_1, np.roll(v, 1), np.nan)
    v_lag2 = np.where(same_2, np.roll(v, 2), np.nan)
    v_lag3 = np.where(same_3, np.roll(v, 3), np.nan)
    v_lag4 = np.where(same_4, np.roll(v, 4), np.nan)
    v_lag5 = np.where(same_5, np.roll(v, 5), np.nan)
    v_ma5 = np.nanmean(np.column_stack([v_lag1, v_lag2, v_lag3, v_lag4, v_lag5]), axis=1)
    safe_v_ma5 = np.where(np.isnan(v_ma5) | (v_ma5 <= 1e-8), np.nan, v_ma5)
    vol_change_ma5 = np.clip((v - safe_v_ma5) / safe_v_ma5, -1.0, 10.0)

    # Lags for Day t-1
    o_t1 = np.where(same_1, np.roll(o, 1), np.nan)
    h_t1 = np.where(same_1, np.roll(h, 1), np.nan)
    l_t1 = np.where(same_1, np.roll(l, 1), np.nan)
    c_t1 = np.where(same_1, np.roll(c, 1), np.nan)
    c_range_t1 = h_t1 - l_t1
    safe_range_t1 = np.where((c_range_t1 <= 1e-8) | np.isnan(c_range_t1), 1.0, c_range_t1)
    safe_c_t1 = np.where((c_t1 <= 1e-8) | np.isnan(c_t1), 1.0, c_t1)

    max_oc_t1 = np.maximum(o_t1, c_t1)
    min_oc_t1 = np.minimum(o_t1, c_t1)
    upper_sh_t1 = np.clip((h_t1 - max_oc_t1) / safe_range_t1, 0.0, 1.0)
    lower_sh_t1 = np.clip((min_oc_t1 - l_t1) / safe_range_t1, 0.0, 1.0)
    body_r_t1 = np.clip(np.abs(c_t1 - o_t1) / safe_range_t1, 0.0, 1.0)
    body_s_t1 = np.clip((c_t1 - o_t1) / safe_range_t1, -1.0, 1.0)
    close_pos_t1 = np.clip((c_t1 - l_t1) / safe_range_t1, 0.0, 1.0)
    open_pos_t1 = np.clip((o_t1 - l_t1) / safe_range_t1, 0.0, 1.0)
    shadow_imb_t1 = np.clip((lower_sh_t1 - upper_sh_t1), -1.0, 1.0)
    d_hl_t1 = np.clip((h_t1 - l_t1) / safe_c_t1, 0.0, 0.30)
    d_lh_t1 = -d_hl_t1
    vol_change_t1 = np.where(same_1, np.roll(vol_change_ma5, 1), np.nan)

    # 2-Day Displacements (t0 vs t1)
    d_open_t1 = np.clip((o - o_t1) / safe_c_t1, -0.30, 0.30)
    d_high_t1 = np.clip((h - h_t1) / safe_c_t1, -0.30, 0.30)
    d_low_t1 = np.clip((l - l_t1) / safe_c_t1, -0.30, 0.30)
    d_close_t1 = np.clip((c - c_t1) / safe_c_t1, -0.30, 0.30)
    gap_open_t1 = np.clip((o - c_t1) / safe_c_t1, -0.30, 0.30)
    d_euclid_t1 = np.sqrt(d_open_t1**2 + d_high_t1**2 + d_low_t1**2 + d_close_t1**2)
    d_manhat_t1 = np.abs(d_open_t1) + np.abs(d_high_t1) + np.abs(d_low_t1) + np.abs(d_close_t1)
    d_high_t0_low_t1 = np.clip((h - l_t1) / safe_c_t1, -0.30, 0.40)
    d_low_t0_high_t1 = np.clip((l - h_t1) / safe_c_t1, -0.40, 0.30)
    d_high_t1_low_t0 = np.clip((h_t1 - l) / safe_c_t1, -0.30, 0.40)
    d_low_t1_high_t0 = np.clip((l_t1 - h) / safe_c_t1, -0.40, 0.30)

    overlap_len_t1 = np.maximum(0.0, np.minimum(h, h_t1) - np.maximum(l, l_t1))
    overlap_r_t1 = np.clip(overlap_len_t1 / safe_range, 0.0, 1.0)
    bo_high_m_t1 = np.clip((h - h_t1) / safe_c_t1, -0.20, 0.20)
    bd_low_m_t1 = np.clip((l - l_t1) / safe_c_t1, -0.20, 0.20)

    # Lags for Day t-2
    o_t2 = np.where(same_2, np.roll(o, 2), np.nan)
    h_t2 = np.where(same_2, np.roll(h, 2), np.nan)
    l_t2 = np.where(same_2, np.roll(l, 2), np.nan)
    c_t2 = np.where(same_2, np.roll(c, 2), np.nan)
    c_range_t2 = h_t2 - l_t2
    safe_range_t2 = np.where((c_range_t2 <= 1e-8) | np.isnan(c_range_t2), 1.0, c_range_t2)
    safe_c_t2 = np.where((c_t2 <= 1e-8) | np.isnan(c_t2), 1.0, c_t2)

    max_oc_t2 = np.maximum(o_t2, c_t2)
    min_oc_t2 = np.minimum(o_t2, c_t2)
    upper_sh_t2 = np.clip((h_t2 - max_oc_t2) / safe_range_t2, 0.0, 1.0)
    lower_sh_t2 = np.clip((min_oc_t2 - l_t2) / safe_range_t2, 0.0, 1.0)
    body_r_t2 = np.clip(np.abs(c_t2 - o_t2) / safe_range_t2, 0.0, 1.0)
    body_s_t2 = np.clip((c_t2 - o_t2) / safe_range_t2, -1.0, 1.0)
    close_pos_t2 = np.clip((c_t2 - l_t2) / safe_range_t2, 0.0, 1.0)
    open_pos_t2 = np.clip((o_t2 - l_t2) / safe_range_t2, 0.0, 1.0)
    shadow_imb_t2 = np.clip((lower_sh_t2 - upper_sh_t2), -1.0, 1.0)
    d_hl_t2 = np.clip((h_t2 - l_t2) / safe_c_t2, 0.0, 0.30)
    d_lh_t2 = -d_hl_t2
    vol_change_t2 = np.where(same_2, np.roll(vol_change_ma5, 2), np.nan)

    # 3-Day Displacements (t1 vs t2, t0 vs t2)
    d_open_t1_t2 = np.clip((o_t1 - o_t2) / safe_c_t2, -0.30, 0.30)
    d_high_t1_t2 = np.clip((h_t1 - h_t2) / safe_c_t2, -0.30, 0.30)
    d_low_t1_t2 = np.clip((l_t1 - l_t2) / safe_c_t2, -0.30, 0.30)
    d_close_t1_t2 = np.clip((c_t1 - c_t2) / safe_c_t2, -0.30, 0.30)
    gap_open_t1_t2 = np.clip((o_t1 - c_t2) / safe_c_t2, -0.30, 0.30)
    d_euclid_t1_t2 = np.sqrt(d_open_t1_t2**2 + d_high_t1_t2**2 + d_low_t1_t2**2 + d_close_t1_t2**2)
    d_manhat_t1_t2 = np.abs(d_open_t1_t2) + np.abs(d_high_t1_t2) + np.abs(d_low_t1_t2) + np.abs(d_close_t1_t2)
    d_high_t1_low_t2 = np.clip((h_t1 - l_t2) / safe_c_t2, -0.30, 0.40)
    d_low_t1_high_t2 = np.clip((l_t1 - h_t2) / safe_c_t2, -0.40, 0.30)
    d_high_t2_low_t1 = np.clip((h_t2 - l_t1) / safe_c_t2, -0.30, 0.40)
    d_low_t2_high_t1 = np.clip((l_t2 - h_t1) / safe_c_t2, -0.40, 0.30)

    d_open_t0_t2 = np.clip((o - o_t2) / safe_c_t2, -0.30, 0.30)
    d_high_t0_t2 = np.clip((h - h_t2) / safe_c_t2, -0.30, 0.30)
    d_low_t0_t2 = np.clip((l - l_t2) / safe_c_t2, -0.30, 0.30)
    d_close_t0_t2 = np.clip((c - c_t2) / safe_c_t2, -0.30, 0.30)
    gap_open_t0_t2 = np.clip((o - c_t2) / safe_c_t2, -0.30, 0.30)
    d_euclid_t0_t2 = np.sqrt(d_open_t0_t2**2 + d_high_t0_t2**2 + d_low_t0_t2**2 + d_close_t0_t2**2)
    d_manhat_t0_t2 = np.abs(d_open_t0_t2) + np.abs(d_high_t0_t2) + np.abs(d_low_t0_t2) + np.abs(d_close_t0_t2)
    d_high_t0_low_t2 = np.clip((h - l_t2) / safe_c_t2, -0.30, 0.40)
    d_low_t0_high_t2 = np.clip((l - h_t2) / safe_c_t2, -0.40, 0.30)
    d_high_t2_low_t0 = np.clip((h_t2 - l) / safe_c_t2, -0.30, 0.40)
    d_low_t2_high_t0 = np.clip((l_t2 - h) / safe_c_t2, -0.40, 0.30)

    # 3-Day Curve & Efficiency
    net_3d = np.abs(c - c_t2)
    path_3d = np.abs(c - c_t1) + np.abs(c_t1 - c_t2)
    safe_path_3d = np.where(path_3d <= 1e-8, 1.0, path_3d)
    efficiency_r_3d = np.clip(net_3d / safe_path_3d, 0.0, 1.0)
    midpoint_line = (c_t2 + c) / 2.0
    curvature_3d = np.clip((c_t1 - midpoint_line) / safe_c_t2, -0.20, 0.20)

    # Forward Targets
    c_f1 = np.where(same_f1, np.roll(c, -1), np.nan)
    c_f3 = np.where(same_f3, np.roll(c, -3), np.nan)
    c_f5 = np.where(same_f5, np.roll(c, -5), np.nan)

    ret_1d = np.clip(c_f1 / safe_c - 1.0, -0.50, 0.50)
    ret_3d = np.clip(c_f3 / safe_c - 1.0, -0.50, 0.50)
    ret_5d = np.clip(c_f5 / safe_c - 1.0, -0.50, 0.50)

    tgt_1d_up3 = np.where(np.isnan(ret_1d), np.nan, (ret_1d >= 0.03).astype(float))
    tgt_3d_up3 = np.where(np.isnan(ret_3d), np.nan, (ret_3d >= 0.03).astype(float))
    tgt_5d_up3 = np.where(np.isnan(ret_5d), np.nan, (ret_5d >= 0.03).astype(float))

    feat_dict = {
        "date": df["date"],
        "stock_id": df["stock_id"],
        "adj_close": c,
        "volume": v,
        "vol_ma5": v_ma5,
        # 1-Day Geometry
        "upper_shadow_ratio_t0": upper_sh,
        "lower_shadow_ratio_t0": lower_sh,
        "body_ratio_t0": body_r,
        "body_signed_t0": body_s,
        "close_pos_t0": close_pos,
        "open_pos_t0": open_pos,
        "shadow_imbalance_t0": shadow_imb,
        "vol_change_vs_ma5_t0": vol_change_ma5,
        "dist_high_low_t0": d_hl_t0,
        "dist_low_high_t0": d_lh_t0,
        # 1-Day Lags
        "upper_shadow_ratio_t1": upper_sh_t1,
        "lower_shadow_ratio_t1": lower_sh_t1,
        "body_ratio_t1": body_r_t1,
        "body_signed_t1": body_s_t1,
        "close_pos_t1": close_pos_t1,
        "open_pos_t1": open_pos_t1,
        "shadow_imbalance_t1": shadow_imb_t1,
        "vol_change_vs_ma5_t1": vol_change_t1,
        "dist_high_low_t1": d_hl_t1,
        "dist_low_high_t1": d_lh_t1,
        # 2-Day Displacements
        "dist_open_t1": d_open_t1,
        "dist_high_t1": d_high_t1,
        "dist_low_t1": d_low_t1,
        "dist_close_t1": d_close_t1,
        "gap_open_t1": gap_open_t1,
        "dist_euclidean_t1": d_euclid_t1,
        "dist_manhattan_t1": d_manhat_t1,
        "dist_high_t0_low_t1": d_high_t0_low_t1,
        "dist_low_t0_high_t1": d_low_t0_high_t1,
        "dist_high_t1_low_t0": d_high_t1_low_t0,
        "dist_low_t1_high_t0": d_low_t1_high_t0,
        "overlap_ratio_t1": overlap_r_t1,
        "breakout_high_margin_t1": bo_high_m_t1,
        "breakdown_low_margin_t1": bd_low_m_t1,
        # 2-Day Lags
        "upper_shadow_ratio_t2": upper_sh_t2,
        "lower_shadow_ratio_t2": lower_sh_t2,
        "body_ratio_t2": body_r_t2,
        "body_signed_t2": body_s_t2,
        "close_pos_t2": close_pos_t2,
        "open_pos_t2": open_pos_t2,
        "shadow_imbalance_t2": shadow_imb_t2,
        "vol_change_vs_ma5_t2": vol_change_t2,
        "dist_high_low_t2": d_hl_t2,
        "dist_low_high_t2": d_lh_t2,
        # 3-Day Displacements
        "dist_open_t1_t2": d_open_t1_t2,
        "dist_high_t1_t2": d_high_t1_t2,
        "dist_low_t1_t2": d_low_t1_t2,
        "dist_close_t1_t2": d_close_t1_t2,
        "gap_open_t1_t2": gap_open_t1_t2,
        "dist_euclidean_t1_t2": d_euclid_t1_t2,
        "dist_manhattan_t1_t2": d_manhat_t1_t2,
        "dist_high_t1_low_t2": d_high_t1_low_t2,
        "dist_low_t1_high_t2": d_low_t1_high_t2,
        "dist_high_t2_low_t1": d_high_t2_low_t1,
        "dist_low_t2_high_t1": d_low_t2_high_t1,
        "dist_open_t0_t2": d_open_t0_t2,
        "dist_high_t0_t2": d_high_t0_t2,
        "dist_low_t0_t2": d_low_t0_t2,
        "dist_close_t0_t2": d_close_t0_t2,
        "gap_open_t0_t2": gap_open_t0_t2,
        "dist_euclidean_t0_t2": d_euclid_t0_t2,
        "dist_manhattan_t0_t2": d_manhat_t0_t2,
        "dist_high_t0_low_t2": d_high_t0_low_t2,
        "dist_low_t0_high_t2": d_low_t0_high_t2,
        "dist_high_t2_low_t0": d_high_t2_low_t0,
        "dist_low_t2_high_t0": d_low_t2_high_t0,
        "efficiency_ratio_3d": efficiency_r_3d,
        "price_curvature_3d": curvature_3d,
        # Returns and Targets
        "ret_1d": ret_1d,
        "ret_3d": ret_3d,
        "ret_5d": ret_5d,
        "target_1d_up3": tgt_1d_up3,
        "target_3d_up3": tgt_3d_up3,
        "target_5d_up3": tgt_5d_up3,
        "has_3d_hist": same_2,
        "has_5d_lead": same_f5,
    }

    out_df = pd.DataFrame(feat_dict)
    out_df = out_df[out_df["date"] >= pd.to_datetime(start_date)].copy()
    out_df = out_df[out_df["has_3d_hist"]].copy()

    # Split labeling
    out_df["split"] = "other"
    out_df.loc[out_df["date"] <= pd.to_datetime(train_end), "split"] = "train"
    out_df.loc[(out_df["date"] > pd.to_datetime(train_end)) & (out_df["date"] <= pd.to_datetime(val_end)), "split"] = "val"
    out_df.loc[out_df["date"] >= pd.to_datetime(test_start), "split"] = "test"

    return out_df.reset_index(drop=True)
