"""
scratch/kline_similarity_subproject/similarity_model.py

K-Line Geometric Similarity Matching Model:
1. Learns Bullish Geometric Prototypes from historical breakout patterns (Y=1) using clustering.
2. Learns Negative/Noise Prototypes from non-breakout patterns (Y=0).
3. Performs Cosine / Metric Similarity Matching between query K-line geometry and historical breakout templates.
4. Outputs calibrated probability and similarity ranking.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import MiniBatchKMeans
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score


class KlineSimilarityMatcher:
    def __init__(
        self,
        n_pos_prototypes: int = 48,
        n_neg_prototypes: int = 48,
        temperature: float = 5.0,
        random_state: int = 42,
    ):
        self.n_pos_prototypes = n_pos_prototypes
        self.n_neg_prototypes = n_neg_prototypes
        self.temperature = temperature
        self.random_state = random_state

        self.scaler = StandardScaler()
        self.pos_prototypes: np.ndarray | None = None
        self.neg_prototypes: np.ndarray | None = None
        self.calibrator = LogisticRegression(C=1.0, max_iter=200, random_state=random_state)
        self.feature_names: list[str] = []

    def fit(self, X: np.ndarray, y: np.ndarray, feature_names: list[str] | None = None):
        """
        Learns bullish and bearish/noise geometric templates from historical training data.
        """
        if feature_names is not None:
            self.feature_names = feature_names

        # 1. Standardize features
        X = np.nan_to_num(X, nan=0.0)
        X_scaled = np.nan_to_num(self.scaler.fit_transform(X), nan=0.0)
        # Normalize to unit length for exact Cosine Similarity
        norms = np.linalg.norm(X_scaled, axis=1, keepdims=True)
        norms = np.where(norms <= 1e-8, 1.0, norms)
        X_norm = np.nan_to_num(X_scaled / norms, nan=0.0)

        pos_mask = (y == 1)
        neg_mask = (y == 0)

        X_pos = X_norm[pos_mask]
        X_neg = X_norm[neg_mask]

        print(f"  [Matcher] Clustering {len(X_pos):,d} positive breakout patterns into {self.n_pos_prototypes} prototypes...")
        kmeans_pos = MiniBatchKMeans(
            n_clusters=self.n_pos_prototypes,
            random_state=self.random_state,
            batch_size=4096,
            max_iter=100,
            n_init=3,
        )
        kmeans_pos.fit(X_pos)
        pos_proto = kmeans_pos.cluster_centers_
        pos_proto_norms = np.linalg.norm(pos_proto, axis=1, keepdims=True)
        self.pos_prototypes = pos_proto / np.where(pos_proto_norms <= 1e-8, 1.0, pos_proto_norms)

        print(f"  [Matcher] Clustering {len(X_neg):,d} negative patterns into {self.n_neg_prototypes} prototypes...")
        kmeans_neg = MiniBatchKMeans(
            n_clusters=self.n_neg_prototypes,
            random_state=self.random_state,
            batch_size=4096,
            max_iter=100,
            n_init=3,
        )
        kmeans_neg.fit(X_neg)
        neg_proto = kmeans_neg.cluster_centers_
        neg_proto_norms = np.linalg.norm(neg_proto, axis=1, keepdims=True)
        self.neg_prototypes = neg_proto / np.where(neg_proto_norms <= 1e-8, 1.0, neg_proto_norms)

        # 2. Extract similarity representations on a representative sample of train set for calibration
        sample_idx = np.random.choice(len(X), size=min(100000, len(X)), replace=False)
        sim_pos = np.dot(X_norm[sample_idx], self.pos_prototypes.T)  # (N, n_pos)
        sim_neg = np.dot(X_norm[sample_idx], self.neg_prototypes.T)  # (N, n_neg)

        # Features for calibration:
        # - Max pos similarity
        # - Mean top 3 pos similarity
        # - Max neg similarity
        # - Mean top 3 neg similarity
        # - Softmax log-odds ratio
        top3_pos = np.sort(sim_pos, axis=1)[:, -3:]
        top3_neg = np.sort(sim_neg, axis=1)[:, -3:]
        
        diff_max = top3_pos[:, -1] - top3_neg[:, -1]
        diff_mean = np.mean(top3_pos, axis=1) - np.mean(top3_neg, axis=1)

        sim_feats = np.column_stack([
            top3_pos[:, -1],              # Max positive similarity
            np.mean(top3_pos, axis=1),    # Top 3 mean positive similarity
            top3_neg[:, -1],              # Max negative similarity
            np.mean(top3_neg, axis=1),    # Top 3 mean negative similarity
            diff_max,                     # Maximum contrast
            diff_mean,                    # Average contrast
        ])

        print(f"  [Matcher] Calibrating similarity scoring function...")
        self.calibrator.fit(sim_feats, y[sample_idx])
        return self

    def predict_similarity_scores(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Computes similarity matching metrics:
        - calibrated_prob: Final calibrated breakout probability
        - max_pos_sim: Maximum cosine similarity to bullish templates [-1, 1]
        - contrast_sim: Positive vs Negative prototype similarity contrast
        """
        X = np.nan_to_num(X, nan=0.0)
        X_scaled = np.nan_to_num(self.scaler.transform(X), nan=0.0)
        norms = np.linalg.norm(X_scaled, axis=1, keepdims=True)
        norms = np.where(norms <= 1e-8, 1.0, norms)
        X_norm = np.nan_to_num(X_scaled / norms, nan=0.0)

        sim_pos = np.dot(X_norm, self.pos_prototypes.T)  # (N, n_pos)
        sim_neg = np.dot(X_norm, self.neg_prototypes.T)  # (N, n_neg)

        top3_pos = np.sort(sim_pos, axis=1)[:, -3:]
        top3_neg = np.sort(sim_neg, axis=1)[:, -3:]

        diff_max = top3_pos[:, -1] - top3_neg[:, -1]
        diff_mean = np.mean(top3_pos, axis=1) - np.mean(top3_neg, axis=1)

        sim_feats = np.nan_to_num(np.column_stack([
            top3_pos[:, -1],
            np.mean(top3_pos, axis=1),
            top3_neg[:, -1],
            np.mean(top3_neg, axis=1),
            diff_max,
            diff_mean,
        ]), nan=0.0)

        probs = self.calibrator.predict_proba(sim_feats)[:, 1]
        return probs, top3_pos[:, -1], diff_max

    def get_most_similar_prototype_id(self, X: np.ndarray) -> np.ndarray:
        """
        Returns the index of the closest bullish prototype for each sample.
        """
        X_scaled = self.scaler.transform(X)
        norms = np.linalg.norm(X_scaled, axis=1, keepdims=True)
        norms = np.where(norms <= 1e-8, 1.0, norms)
        X_norm = X_scaled / norms
        sim_pos = np.dot(X_norm, self.pos_prototypes.T)
        return np.argmax(sim_pos, axis=1)
