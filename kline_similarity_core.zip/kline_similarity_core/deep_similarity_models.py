"""
scratch/kline_similarity_subproject/deep_similarity_models.py

Three Deep Learning Similarity Matching Architectures:
1. SiameseTripletNet: Deep Siamese Encoder with Triplet Margin Loss
2. DeepProtoNet: Deep Prototypical Network with Episodic Centroid Matching
3. SupConNet: Supervised Contrastive Learning Network (SupCon Loss)
"""

from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import numpy as np


DEVICE = torch.device("mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu"))


class BalancedKlineDataset(Dataset):
    """
    Dataset that provides balanced positive and negative pairs/triplets for metric learning.
    """
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.from_numpy(X.astype(np.float32))
        self.y = torch.from_numpy(y.astype(np.int64))
        self.pos_indices = np.where(y == 1)[0]
        self.neg_indices = np.where(y == 0)[0]
        self.n_pos = len(self.pos_indices)
        self.n_neg = len(self.neg_indices)

    def __len__(self):
        # Anchor on positive count multiplied by balance factor
        return min(self.n_pos * 2, 80000)

    def __getitem__(self, idx):
        # Half positive, half negative anchors
        if idx % 2 == 0:
            anchor_idx = self.pos_indices[np.random.randint(0, self.n_pos)]
            pos_idx = self.pos_indices[np.random.randint(0, self.n_pos)]
            neg_idx = self.neg_indices[np.random.randint(0, self.n_neg)]
            label = 1
        else:
            anchor_idx = self.neg_indices[np.random.randint(0, self.n_neg)]
            pos_idx = self.pos_indices[np.random.randint(0, self.n_pos)]
            neg_idx = self.neg_indices[np.random.randint(0, self.n_neg)]
            label = 0

        return (
            self.X[anchor_idx],
            self.X[pos_idx],
            self.X[neg_idx],
            label,
        )


# ==============================================================================
# 1. Siamese Network with Triplet Margin Loss
# ==============================================================================
class SiameseEncoder(nn.Module):
    def __init__(self, in_dim: int, latent_dim: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.LayerNorm(64),
            nn.GELU(),
            nn.Linear(64, 48),
            nn.LayerNorm(48),
            nn.GELU(),
            nn.Linear(48, latent_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.net(x)
        # Normalize to unit sphere for cosine distance
        return F.normalize(z, p=2, dim=-1)


class SiameseTripletMatcher:
    def __init__(self, in_dim: int, latent_dim: int = 32, margin: float = 0.25, lr: float = 1e-3):
        self.encoder = SiameseEncoder(in_dim, latent_dim).to(DEVICE)
        self.latent_dim = latent_dim
        self.margin = margin
        self.lr = lr
        self.pos_prototype: torch.Tensor | None = None
        self.neg_prototype: torch.Tensor | None = None

    def fit(self, X_train: np.ndarray, y_train: np.ndarray, epochs: int = 4, batch_size: int = 2048):
        dataset = BalancedKlineDataset(X_train, y_train)
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)
        optimizer = torch.optim.AdamW(self.encoder.parameters(), lr=self.lr, weight_decay=1e-4)
        criterion = nn.TripletMarginLoss(margin=self.margin, p=2)

        self.encoder.train()
        for epoch in range(epochs):
            total_loss = 0.0
            steps = 0
            for anchor, pos, neg, _ in loader:
                anchor, pos, neg = anchor.to(DEVICE), pos.to(DEVICE), neg.to(DEVICE)
                optimizer.zero_grad()
                z_a = self.encoder(anchor)
                z_p = self.encoder(pos)
                z_n = self.encoder(neg)

                loss = criterion(z_a, z_p, z_n)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
                steps += 1

        # Compute positive and negative class prototypes in latent space
        self.encoder.eval()
        with torch.no_grad():
            pos_mask = (y_train == 1)
            neg_mask = (y_train == 0)

            # Sample subset for fast prototype computation
            pos_sub = X_train[pos_mask][:20000]
            neg_sub = X_train[neg_mask][:20000]

            z_pos = self.encoder(torch.from_numpy(pos_sub).float().to(DEVICE))
            z_neg = self.encoder(torch.from_numpy(neg_sub).float().to(DEVICE))

            self.pos_prototype = F.normalize(z_pos.mean(dim=0, keepdim=True), p=2, dim=-1)
            self.neg_prototype = F.normalize(z_neg.mean(dim=0, keepdim=True), p=2, dim=-1)

    def predict_similarity(self, X_test: np.ndarray, temperature: float = 0.15) -> tuple[np.ndarray, np.ndarray]:
        self.encoder.eval()
        with torch.no_grad():
            X_tensor = torch.from_numpy(X_test).float().to(DEVICE)
            z = self.encoder(X_tensor)  # (N, latent_dim)

            # Cosine similarities to positive and negative prototypes
            sim_pos = torch.mm(z, self.pos_prototype.T).squeeze(-1)  # (N,)
            sim_neg = torch.mm(z, self.neg_prototype.T).squeeze(-1)  # (N,)

            # Softmax probability with temperature scaling
            logits = torch.stack([sim_neg / temperature, sim_pos / temperature], dim=-1)
            probs = F.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            pos_sims = sim_pos.cpu().numpy()

        return probs, pos_sims


# ==============================================================================
# 2. Deep Prototypical Network (ProtoNet)
# ==============================================================================
class ProtoEncoder(nn.Module):
    def __init__(self, in_dim: int, embed_dim: int = 32):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Linear(64, 48),
            nn.BatchNorm1d(48),
            nn.ReLU(),
            nn.Linear(48, embed_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)


class DeepProtoMatcher:
    def __init__(self, in_dim: int, embed_dim: int = 32, lr: float = 1e-3):
        self.encoder = ProtoEncoder(in_dim, embed_dim).to(DEVICE)
        self.embed_dim = embed_dim
        self.lr = lr
        self.c_pos: torch.Tensor | None = None
        self.c_neg: torch.Tensor | None = None

    def fit(self, X_train: np.ndarray, y_train: np.ndarray, epochs: int = 4, batch_size: int = 2048):
        optimizer = torch.optim.AdamW(self.encoder.parameters(), lr=self.lr, weight_decay=1e-4)
        pos_idx = np.where(y_train == 1)[0]
        neg_idx = np.where(y_train == 0)[0]
        n_pos = len(pos_idx)
        n_neg = len(neg_idx)

        X_t = torch.from_numpy(X_train).float()
        self.encoder.train()

        steps_per_epoch = 40
        half_b = batch_size // 2

        for epoch in range(epochs):
            for _ in range(steps_per_epoch):
                p_batch = pos_idx[np.random.randint(0, n_pos, half_b)]
                n_batch = neg_idx[np.random.randint(0, n_neg, half_b)]

                batch_idx = np.concatenate([p_batch, n_batch])
                labels = torch.cat([torch.ones(half_b), torch.zeros(half_b)]).long().to(DEVICE)

                x_b = X_t[batch_idx].to(DEVICE)
                z_b = self.encoder(x_b)

                # Compute episodic prototypes
                c_p = z_b[:half_b].mean(dim=0)
                c_n = z_b[half_b:].mean(dim=0)

                # Distances
                d_p = torch.sum((z_b - c_p) ** 2, dim=-1)
                d_n = torch.sum((z_b - c_n) ** 2, dim=-1)

                logits = torch.stack([-d_n, -d_p], dim=-1)  # class 0 vs class 1
                loss = F.cross_entropy(logits, labels)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        # Final global prototypes
        self.encoder.eval()
        with torch.no_grad():
            sub_p = X_t[pos_idx[:30000]].to(DEVICE)
            sub_n = X_t[neg_idx[:30000]].to(DEVICE)
            self.c_pos = self.encoder(sub_p).mean(dim=0, keepdim=True)
            self.c_neg = self.encoder(sub_n).mean(dim=0, keepdim=True)

    def predict_similarity(self, X_test: np.ndarray, temperature: float = 2.0) -> tuple[np.ndarray, np.ndarray]:
        self.encoder.eval()
        with torch.no_grad():
            X_tensor = torch.from_numpy(X_test).float().to(DEVICE)
            z = self.encoder(X_tensor)

            # Euclidean distances to prototypes
            d_p = torch.sum((z - self.c_pos) ** 2, dim=-1)
            d_n = torch.sum((z - self.c_neg) ** 2, dim=-1)

            logits = torch.stack([-d_n / temperature, -d_p / temperature], dim=-1)
            probs = F.softmax(logits, dim=-1)[:, 1].cpu().numpy()

            # Normalized distance as similarity measure
            sim_pos = (-d_p).cpu().numpy()

        return probs, sim_pos


# ==============================================================================
# 3. Supervised Contrastive Network (SupCon)
# ==============================================================================
class SupConEncoder(nn.Module):
    def __init__(self, in_dim: int, proj_dim: int = 16):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.LayerNorm(64),
            nn.GELU(),
            nn.Linear(64, 48),
            nn.LayerNorm(48),
            nn.GELU(),
            nn.Linear(48, 32),
        )
        self.head = nn.Sequential(
            nn.Linear(32, proj_dim),
        )

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feat = self.backbone(x)
        proj = F.normalize(self.head(feat), p=2, dim=-1)
        return feat, proj


def supcon_loss(features: torch.Tensor, labels: torch.Tensor, temperature: float = 0.1) -> torch.Tensor:
    """
    Supervised Contrastive Loss (Khosla et al., NeurIPS 2020)
    """
    device = features.device
    batch_size = features.shape[0]
    labels = labels.contiguous().view(-1, 1)
    mask = torch.eq(labels, labels.T).float().to(device)

    # Cosine similarity matrix
    anchor_dot_contrast = torch.div(torch.matmul(features, features.T), temperature)
    # For numerical stability
    logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
    logits = anchor_dot_contrast - logits_max.detach()

    # Mask-out self-contrast cases
    logits_mask = torch.scatter(
        torch.ones_like(mask),
        1,
        torch.arange(batch_size).view(-1, 1).to(device),
        0
    )
    mask = mask * logits_mask

    # Compute log_prob
    exp_logits = torch.exp(logits) * logits_mask
    log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True) + 1e-8)

    # Mean of log-likelihood over positive pairs
    mean_log_prob_pos = (mask * log_prob).sum(1) / (mask.sum(1) + 1e-8)
    loss = -mean_log_prob_pos.mean()
    return loss


class SupConMatcher:
    def __init__(self, in_dim: int, lr: float = 1e-3, temperature: float = 0.1):
        self.model = SupConEncoder(in_dim).to(DEVICE)
        self.lr = lr
        self.temperature = temperature
        self.pos_prototype: torch.Tensor | None = None
        self.neg_prototype: torch.Tensor | None = None

    def fit(self, X_train: np.ndarray, y_train: np.ndarray, epochs: int = 4, batch_size: int = 2048):
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        pos_idx = np.where(y_train == 1)[0]
        neg_idx = np.where(y_train == 0)[0]
        n_pos = len(pos_idx)
        n_neg = len(neg_idx)

        X_t = torch.from_numpy(X_train).float()
        self.model.train()

        steps_per_epoch = 40
        half_b = batch_size // 2

        for epoch in range(epochs):
            for _ in range(steps_per_epoch):
                p_batch = pos_idx[np.random.randint(0, n_pos, half_b)]
                n_batch = neg_idx[np.random.randint(0, n_neg, half_b)]

                batch_idx = np.concatenate([p_batch, n_batch])
                labels = torch.cat([torch.ones(half_b), torch.zeros(half_b)]).long().to(DEVICE)

                x_b = X_t[batch_idx].to(DEVICE)
                _, proj_b = self.model(x_b)

                loss = supcon_loss(proj_b, labels, temperature=self.temperature)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        self.model.eval()
        with torch.no_grad():
            sub_p = X_t[pos_idx[:30000]].to(DEVICE)
            sub_n = X_t[neg_idx[:30000]].to(DEVICE)
            _, proj_p = self.model(sub_p)
            _, proj_n = self.model(sub_n)
            self.pos_prototype = F.normalize(proj_p.mean(dim=0, keepdim=True), p=2, dim=-1)
            self.neg_prototype = F.normalize(proj_n.mean(dim=0, keepdim=True), p=2, dim=-1)

    def predict_similarity(self, X_test: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        self.model.eval()
        with torch.no_grad():
            X_tensor = torch.from_numpy(X_test).float().to(DEVICE)
            _, proj = self.model(X_tensor)

            sim_pos = torch.mm(proj, self.pos_prototype.T).squeeze(-1)
            sim_neg = torch.mm(proj, self.neg_prototype.T).squeeze(-1)

            logits = torch.stack([sim_neg / self.temperature, sim_pos / self.temperature], dim=-1)
            probs = F.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            pos_sims = sim_pos.cpu().numpy()

        return probs, pos_sims
