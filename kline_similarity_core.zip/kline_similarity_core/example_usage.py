"""
example_usage.py
================
Demonstration of using the pure K-Line Similarity Metric Learning Engine.
No backtests, no comparative benchmarks, no charts - purely feature extraction
and prototype similarity prediction.
"""

from pathlib import Path
import numpy as np
import pandas as pd

from features import build_kline_features
from pipeline import KlineSimilarityEngine


def main():
    print("=" * 70)
    print(" K-Line Similarity Matching Engine: Minimal Demonstration")
    print("=" * 70)

    # 1. Create Synthetic / Mock OHLCV data (or replace with real OHLCV DataFrame)
    print("\n[Step 1] Creating sample multi-stock OHLCV sequence (5 stocks, 100 days)...")
    np.random.seed(42)
    dates = pd.date_range("2024-01-01", periods=100, freq="B")
    stock_ids = ["2330", "2317", "2454", "2308", "2382"]

    records = []
    for s in stock_ids:
        base_price = np.random.uniform(50, 500)
        curr = base_price
        for d in dates:
            ret = np.random.normal(0.001, 0.02)
            c = curr * (1 + ret)
            h = max(curr, c) * (1 + abs(np.random.normal(0, 0.008)))
            l = min(curr, c) * (1 - abs(np.random.normal(0, 0.008)))
            o = curr
            v = np.random.uniform(2000, 50000) * 1000  # in shares
            records.append({
                "date": d,
                "stock_id": s,
                "open": o,
                "high": h,
                "low": l,
                "adj_close": c,
                "volume": v,
            })
            curr = c

    df_sample = pd.DataFrame(records)
    print(f"  Mock OHLCV Shape: {df_sample.shape}")

    # 2. Extract 1D, 2D, 3D Dimensionless Candlestick Geometries
    print("\n[Step 2] Extracting K-line dimensionless geometries...")
    df_features = build_kline_features(df=df_sample, start_date="2024-01-05")
    print(f"  Extracted Features DataFrame: {df_features.shape}")
    print(f"  Sample feature columns: {[c for c in df_features.columns if 'ratio' in c or 'curvature' in c][:5]}")

    # 3. Train KlineSimilarityEngine
    print("\n[Step 3] Fitting prototype similarity engine...")
    # For demonstration, use a small prototype count (8 pos, 8 neg)
    engine = KlineSimilarityEngine(n_pos_prototypes=8, n_neg_prototypes=8, random_state=42)
    # Split train and query
    train_slice = df_features.iloc[:350].copy()
    query_slice = df_features.iloc[350:].copy()

    engine.fit(train_slice)

    # 4. Predict Similarity Probabilities and Trinity Alpha
    print("\n[Step 4] Querying similarity matcher on unseen candlestick data...")
    predictions = engine.predict(query_slice)
    print("  Predictions successfully generated:")
    print(predictions[["date", "stock_id", "prob_1d_5d", "prob_2d_1d", "prob_3d_5d", "kline_trinity_alpha"]].head(10))

    # 5. Serialization Check
    model_path = Path("/tmp/sample_kline_engine.pkl")
    engine.save(model_path)
    loaded_engine = KlineSimilarityEngine.load(model_path)
    loaded_preds = loaded_engine.predict(query_slice)
    assert np.allclose(predictions["kline_trinity_alpha"].values, loaded_preds["kline_trinity_alpha"].values)
    model_path.unlink()
    print("\n[Verification] Model save/load pipeline check PASSED (Exact numerical match).")

    print("\n" + "=" * 70)
    print(" Complete: Core Similarity Matching Pipeline is 100% Operational.")
    print("=" * 70)


if __name__ == "__main__":
    main()
