"""
kline_similarity_core.pipeline
==============================
High-Level KlineSimilarityEngine for End-to-End Prototype Matching:
1. Ingests raw OHLCV or precomputed geometric feature DataFrame.
2. Fits prototype clustering and calibration (1D-5D, 2D-1D, 3D-5D engines).
3. Predicts breakout matching probabilities and cross-sectional Trinity Alpha.
4. Provides single-file serialization (save/load) for production inference.
"""

from __future__ import annotations
import pickle
from pathlib import Path
import numpy as np
import pandas as pd

try:
    from .features import (
        build_kline_features,
        FEATURES_1DAY,
        FEATURES_2DAY,
        FEATURES_3DAY,
    )
    from .similarity_model import KlineSimilarityMatcher
except ImportError:
    from features import (
        build_kline_features,
        FEATURES_1DAY,
        FEATURES_2DAY,
        FEATURES_3DAY,
    )
    from similarity_model import KlineSimilarityMatcher


class KlineSimilarityEngine:
    """
    Unified geometric similarity inference engine for candlestick pattern matching.
    """
    def __init__(
        self,
        n_pos_prototypes: int = 48,
        n_neg_prototypes: int = 48,
        temperature: float = 5.0,
        random_state: int = 42,
    ):
        self.n_pos_prototypes = n_pos_prototypes
        self.n_neg_prototypes = n_neg_prototypes
        self.temperature = temperature
        self.random_state = random_state

        # Three dedicated engines
        self.engine_1d_5d = KlineSimilarityMatcher(n_pos_prototypes, n_neg_prototypes, temperature, random_state)
        self.engine_2d_1d = KlineSimilarityMatcher(n_pos_prototypes, n_neg_prototypes, temperature, random_state)
        self.engine_3d_5d = KlineSimilarityMatcher(n_pos_prototypes, n_neg_prototypes, temperature, random_state)
        
        self.is_fitted = False

    def fit(self, df_train: pd.DataFrame) -> "KlineSimilarityEngine":
        """
        Trains geometric prototypes from training set features and target breakout labels.
        Requires:
        - FEATURES_1DAY & target_5d_up3
        - FEATURES_2DAY & target_1d_up3
        - FEATURES_3DAY & target_5d_up3
        """
        print("[KlineEngine] Training 1D-5D Prototype Engine...")
        mask_1d = df_train["target_5d_up3"].notna()
        X_1d = df_train.loc[mask_1d, FEATURES_1DAY].values
        y_1d = df_train.loc[mask_1d, "target_5d_up3"].values.astype(int)
        self.engine_1d_5d.fit(X_1d, y_1d, FEATURES_1DAY)

        print("[KlineEngine] Training 2D-1D Prototype Engine...")
        mask_2d = df_train["target_1d_up3"].notna()
        X_2d = df_train.loc[mask_2d, FEATURES_2DAY].values
        y_2d = df_train.loc[mask_2d, "target_1d_up3"].values.astype(int)
        self.engine_2d_1d.fit(X_2d, y_2d, FEATURES_2DAY)

        print("[KlineEngine] Training 3D-5D Prototype Engine...")
        mask_3d = df_train["target_5d_up3"].notna()
        X_3d = df_train.loc[mask_3d, FEATURES_3DAY].values
        y_3d = df_train.loc[mask_3d, "target_5d_up3"].values.astype(int)
        self.engine_3d_5d.fit(X_3d, y_3d, FEATURES_3DAY)

        self.is_fitted = True
        return self

    def predict(self, df_query: pd.DataFrame) -> pd.DataFrame:
        """
        Generates similarity predictions on query data:
        - prob_1d_5d: 1-day single candlestick breakout probability
        - prob_2d_1d: 2-day consecutive gap/breakout continuation probability
        - prob_3d_5d: 3-day multi-day wave structure probability
        - kline_trinity_alpha: Cross-sectional composite alpha (0.3 * Rank(2D) + 0.7 * Rank(3D))
        """
        if not self.is_fitted:
            raise RuntimeError("KlineSimilarityEngine must be fitted or loaded before calling predict().")

        out = df_query[["date", "stock_id"]].copy() if "date" in df_query and "stock_id" in df_query else pd.DataFrame(index=df_query.index)

        X_1d = df_query[FEATURES_1DAY].values
        X_2d = df_query[FEATURES_2DAY].values
        X_3d = df_query[FEATURES_3DAY].values

        p_1d, _, _ = self.engine_1d_5d.predict_similarity_scores(X_1d)
        p_2d, _, _ = self.engine_2d_1d.predict_similarity_scores(X_2d)
        p_3d, _, _ = self.engine_3d_5d.predict_similarity_scores(X_3d)

        out["prob_1d_5d"] = p_1d
        out["prob_2d_1d"] = p_2d
        out["prob_3d_5d"] = p_3d

        # Cross-sectional percentiles and composite Trinity Alpha
        if "date" in out.columns:
            r_2d = out.groupby("date")["prob_2d_1d"].rank(pct=True)
            r_3d = out.groupby("date")["prob_3d_5d"].rank(pct=True)
            out["kline_trinity_alpha"] = 0.3 * r_2d + 0.7 * r_3d
        else:
            out["kline_trinity_alpha"] = 0.3 * out["prob_2d_1d"].rank(pct=True) + 0.7 * out["prob_3d_5d"].rank(pct=True)

        return out

    def save(self, filepath: str | Path):
        """Saves trained engine to disk."""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "wb") as f:
            pickle.dump(self, f)
        print(f"[KlineEngine] Successfully saved engine to {filepath}")

    @classmethod
    def load(cls, filepath: str | Path) -> "KlineSimilarityEngine":
        """Loads trained engine from disk."""
        with open(filepath, "rb") as f:
            engine = pickle.load(f)
        return engine
